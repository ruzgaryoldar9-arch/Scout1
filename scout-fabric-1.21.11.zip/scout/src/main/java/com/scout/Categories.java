package com.scout;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.List;

/** Chunk Finder'da secilebilen blok gruplari. Yeni grup eklemek icin listeye bir satir yeterli. */
public final class Categories {
    public static final class Category {
        public final String id, label;
        public final int rgb;
        public final Block[] blocks;
        Category(String id, String label, int rgb, Block... blocks) {
            this.id = id; this.label = label; this.rgb = rgb; this.blocks = blocks;
        }
    }

    public static final List<Category> LIST = List.of(
        new Category("budding_amethyst", "Budding Amethyst", 0xB36BFF, Blocks.BUDDING_AMETHYST),
        new Category("amethyst", "Amethyst Cluster/Bud", 0xD9A8FF, Blocks.AMETHYST_CLUSTER,
                Blocks.LARGE_AMETHYST_BUD, Blocks.MEDIUM_AMETHYST_BUD, Blocks.SMALL_AMETHYST_BUD),
        new Category("kelp", "Kelp", 0x2E8B3A, Blocks.KELP, Blocks.KELP_PLANT),
        new Category("sugar_cane", "Sugar Cane", 0x9BE36B, Blocks.SUGAR_CANE),
        new Category("cactus", "Cactus", 0x3FA34D, Blocks.CACTUS),
        new Category("bamboo", "Bamboo", 0x7DC95E, Blocks.BAMBOO, Blocks.BAMBOO_SAPLING),
        new Category("pumpkin", "Pumpkin", 0xFF8C1A, Blocks.PUMPKIN),
        new Category("melon", "Melon", 0x66CC33, Blocks.MELON),
        new Category("crops", "Farmland / Crops", 0xC2A04B, Blocks.FARMLAND, Blocks.WHEAT, Blocks.CARROTS, Blocks.POTATOES),
        new Category("sea_pickle", "Sea Pickle", 0xB5E61D, Blocks.SEA_PICKLE),
        new Category("cave_vines", "Glow Berries", 0xFFD34D, Blocks.CAVE_VINES, Blocks.CAVE_VINES_PLANT),
        new Category("sweet_berry", "Sweet Berry Bush", 0xD94A4A, Blocks.SWEET_BERRY_BUSH),
        new Category("nether_wart", "Nether Wart", 0xC21E3A, Blocks.NETHER_WART),
        new Category("chorus", "Chorus Plant/Flower", 0xA67CC4, Blocks.CHORUS_PLANT, Blocks.CHORUS_FLOWER),
        new Category("dripstone", "Pointed Dripstone", 0x8B6B4A, Blocks.POINTED_DRIPSTONE),
        new Category("sculk", "Sculk Shrieker/Catalyst", 0x0F5C6B, Blocks.SCULK_SHRIEKER, Blocks.SCULK_CATALYST),
        new Category("obsidian", "Obsidian", 0x2A1A4A, Blocks.OBSIDIAN),
        new Category("ancient_debris", "Ancient Debris", 0x6B3F2A, Blocks.ANCIENT_DEBRIS),
        new Category("beacon", "Beacon", 0x66FFFF, Blocks.BEACON),
        new Category("end_frame", "End Portal Frame", 0x99CC99, Blocks.END_PORTAL_FRAME),
        new Category("nether_portal", "Nether Portal", 0x8A2BE2, Blocks.NETHER_PORTAL),
        new Category("torch", "Torch / Lantern", 0xFFE066, Blocks.TORCH, Blocks.WALL_TORCH, Blocks.LANTERN),
        new Category("rails", "Rails", 0xBBBBBB, Blocks.RAIL, Blocks.POWERED_RAIL, Blocks.DETECTOR_RAIL, Blocks.ACTIVATOR_RAIL),
        new Category("redstone", "Piston/Observer/Comparator", 0xFF3030, Blocks.PISTON, Blocks.STICKY_PISTON,
                Blocks.OBSERVER, Blocks.REPEATER, Blocks.COMPARATOR),
        new Category("cobweb", "Cobweb", 0xE0E0E0, Blocks.COBWEB)
    );

    private Categories() {}
}
