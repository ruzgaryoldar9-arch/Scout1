package com.scout;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public class Scout implements ClientModInitializer {
    private static KeyMapping openKey;
    private static boolean openRequested;

    @Override
    public void onInitializeClient() {
        Config.get();
        Renderer.init();

        // Sag Shift = GUI
        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("scout", "main"));
        openKey = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.scout.open", InputConstants.Type.KEYSYM, InputConstants.KEY_RSHIFT, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new ScoutScreen(null));
            }
            if (openRequested && mc.screen == null) {
                openRequested = false;
                mc.setScreen(new ScoutScreen(null));
            }
            Tracker.tick(mc);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> Tracker.reset());

        // Mobil: /scout komutu
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) ->
                dispatcher.register(ClientCommandManager.literal("scout").executes(ctx -> {
                    openRequested = true;
                    return 1;
                })));

        // Mobil: Pause menusune "Scout" butonu (klavye gerekmez)
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof PauseScreen) {
                Screens.getButtons(screen).add(Button.builder(Component.literal("Scout"),
                        b -> Minecraft.getInstance().setScreen(new ScoutScreen(screen)))
                        .bounds(6, 6, 70, 24).build());
            }
        });
    }
}
