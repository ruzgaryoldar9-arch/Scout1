package com.scout;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.block.entity.TrialSpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

import java.util.*;

/** Tum tarama mantigi (storage, spawner, chunk finder). Hepsi ana thread'de calisir. */
public final class Tracker {
    public record Box(double x1, double y1, double z1, double x2, double y2, double z2,
                      float r, float g, float b, float a) {}

    private record Hit(int cx, int cz, int total, int rgb, double avgY, long[] sample) {}

    private static List<Box> storage = List.of(), spawners = List.of(), chunkBoxes = List.of(), all = List.of();
    private static final Map<Long, Hit> hits = new HashMap<>();
    private static final Set<Long> announced = new HashSet<>();
    private static final Map<Block, Integer> catIndex = new HashMap<>();
    private static List<int[]> order = new ArrayList<>();
    private static int tick, cursor, lastSig = 0, lastPcx = Integer.MIN_VALUE, lastPcz = Integer.MIN_VALUE;

    private Tracker() {}

    public static List<Box> all() { return all; }

    public static void invalidate() { lastSig = 0; }

    public static void reset() {
        storage = spawners = chunkBoxes = all = List.of();
        hits.clear(); announced.clear(); order.clear();
        cursor = 0; lastSig = 0; lastPcx = Integer.MIN_VALUE;
    }

    public static void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null) {
            if (!all.isEmpty()) reset();
            return;
        }
        Config c = Config.get();
        tick++;

        if (tick % (c.mobileMode ? 20 : 10) == 0) scanEntities(mc, c);
        if (c.chunkFinder) scanChunks(mc, c); else chunkBoxes = List.of();
        if (!c.storageEsp) storage = List.of();
        if (!c.spawnerEsp) spawners = List.of();

        if (tick % 5 == 0) {
            int cap = c.mobileMode ? 500 : 1500;
            List<Box> out = new ArrayList<>();
            for (List<Box> l : List.of(spawners, storage, chunkBoxes)) {
                for (Box b : l) { if (out.size() >= cap) break; out.add(b); }
            }
            all = out;
        }
    }

    // ------------------------------------------------------------------ storage + spawner

    private static void scanEntities(Minecraft mc, Config c) {
        if (!c.storageEsp && !c.spawnerEsp) return;
        int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
        int r = (c.espRange >> 4) + 1;
        double max2 = (double) c.espRange * c.espRange;
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        float a = c.alphaPercent / 100f;

        List<Box> st = new ArrayList<>(), sp = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                LevelChunk ch = mc.level.getChunkSource().getChunkNow(pcx + dx, pcz + dz);
                if (ch == null) continue;
                for (BlockEntity be : new ArrayList<>(ch.getBlockEntities().values())) {
                    BlockPos p = be.getBlockPos();
                    if (p.distToCenterSqr(px, py, pz) > max2) continue;

                    if (be instanceof SpawnerBlockEntity || be instanceof TrialSpawnerBlockEntity) {
                        if (!c.spawnerEsp) continue;
                        sp.add(blockBox(p, 0xFF2020, Math.min(1f, a + 0.25f)));
                        if (c.spawnerChat && announced.add(p.asLong())) {
                            mc.player.displayClientMessage(Component.literal(
                                    "[Scout] Spawner: " + p.getX() + " " + p.getY() + " " + p.getZ()), false);
                        }
                    } else if (c.storageEsp) {
                        int col = storageColor(be, c);
                        if (col != 0) st.add(blockBox(p, col, a));
                    }
                }
            }
        }
        storage = st;
        spawners = sp;
    }

    private static int storageColor(BlockEntity be, Config c) {
        if (be instanceof TrappedChestBlockEntity) return c.trappedChests ? 0xFF4040 : 0;
        if (be instanceof ChestBlockEntity) return c.chests ? 0xFFA500 : 0;
        if (be instanceof EnderChestBlockEntity) return c.enderChests ? 0xA040FF : 0;
        if (be instanceof BarrelBlockEntity) return c.barrels ? 0xC08040 : 0;
        if (be instanceof ShulkerBoxBlockEntity) return c.shulkers ? 0xFF55FF : 0;
        if (be instanceof HopperBlockEntity) return c.hoppers ? 0x909090 : 0;
        if (be instanceof DispenserBlockEntity) return c.dispensers ? 0x70A0FF : 0;
        if (be instanceof AbstractFurnaceBlockEntity) return c.furnaces ? 0xDDDDDD : 0;
        return 0;
    }

    // ------------------------------------------------------------------ chunk finder

    private static void rebuildIndex(Config c) {
        catIndex.clear();
        for (int i = 0; i < Categories.LIST.size(); i++) {
            Categories.Category cat = Categories.LIST.get(i);
            if (!c.finderBlocks.contains(cat.id)) continue;
            for (Block b : cat.blocks) catIndex.put(b, i);
        }
    }

    private static long key(int cx, int cz) { return ((long) cx << 32) | (cz & 0xFFFFFFFFL); }

    private static void scanChunks(Minecraft mc, Config c) {
        int radius = Math.min(c.finderRadius, c.mobileMode ? 6 : 16);
        int sig = c.finderBlocks.hashCode() * 31 + radius + 7;
        if (sig != lastSig) {
            lastSig = sig;
            hits.clear(); order.clear(); cursor = 0; lastPcx = Integer.MIN_VALUE;
            rebuildIndex(c);
        }
        if (catIndex.isEmpty()) { chunkBoxes = List.of(); return; }

        int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
        if (pcx != lastPcx || pcz != lastPcz || order.isEmpty()) {
            lastPcx = pcx; lastPcz = pcz; cursor = 0;
            order = new ArrayList<>();
            for (int dx = -radius; dx <= radius; dx++)
                for (int dz = -radius; dz <= radius; dz++)
                    if (dx * dx + dz * dz <= radius * radius + radius) order.add(new int[]{pcx + dx, pcz + dz});
            order.sort(Comparator.comparingInt(o -> (o[0] - pcx) * (o[0] - pcx) + (o[1] - pcz) * (o[1] - pcz)));
            hits.values().removeIf(h -> Math.abs(h.cx - pcx) > radius || Math.abs(h.cz - pcz) > radius);
        }

        int budget = c.mobileMode ? 1 : 3;
        for (int i = 0; i < budget && !order.isEmpty(); i++) {
            int[] o = order.get(cursor);
            cursor = (cursor + 1) % order.size();
            LevelChunk ch = mc.level.getChunkSource().getChunkNow(o[0], o[1]);
            if (ch == null) { hits.remove(key(o[0], o[1])); continue; }
            Hit h = scan(mc, ch, o[0], o[1]);
            if (h == null) hits.remove(key(o[0], o[1])); else hits.put(key(o[0], o[1]), h);
        }

        if (tick % 10 == 0) rebuildChunkBoxes(c);
    }

    private static Hit scan(Minecraft mc, LevelChunk ch, int cx, int cz) {
        LevelChunkSection[] secs = ch.getSections();
        int minY = mc.level.dimensionType().minY();
        int[] counts = new int[Categories.LIST.size()];
        long[] sample = new long[48];
        int total = 0, sn = 0;
        double sumY = 0;

        for (int si = 0; si < secs.length; si++) {
            LevelChunkSection s = secs[si];
            if (s == null || s.hasOnlyAir() || !s.maybeHas(st -> catIndex.containsKey(st.getBlock()))) continue;
            int baseY = minY + si * 16;
            for (int y = 0; y < 16; y++)
                for (int z = 0; z < 16; z++)
                    for (int x = 0; x < 16; x++) {
                        BlockState st = s.getBlockState(x, y, z);
                        Integer idx = catIndex.get(st.getBlock());
                        if (idx == null) continue;
                        counts[idx]++; total++; sumY += baseY + y;
                        if (sn < sample.length) sample[sn++] = BlockPos.asLong(cx * 16 + x, baseY + y, cz * 16 + z);
                    }
        }
        if (total == 0) return null;
        int best = 0;
        for (int i = 1; i < counts.length; i++) if (counts[i] > counts[best]) best = i;
        return new Hit(cx, cz, total, Categories.LIST.get(best).rgb, sumY / total, Arrays.copyOf(sample, sn));
    }

    private static void rebuildChunkBoxes(Config c) {
        float a = c.alphaPercent / 100f;
        List<Box> out = new ArrayList<>();
        for (Hit h : hits.values()) {
            if (h.total < c.finderThreshold) continue;
            float r = ((h.rgb >> 16) & 255) / 255f, g = ((h.rgb >> 8) & 255) / 255f, b = (h.rgb & 255) / 255f;
            double x = h.cx * 16.0, z = h.cz * 16.0;
            out.add(new Box(x, h.avgY, z, x + 16, h.avgY + 0.4, z + 16, r, g, b, Math.min(1f, a)));
            if (c.showFinderBlocks) {
                for (long l : h.sample) out.add(blockBox(BlockPos.of(l), h.rgb, Math.min(1f, a + 0.2f)));
            }
        }
        chunkBoxes = out;
    }

    // ------------------------------------------------------------------ yardimci

    private static Box blockBox(BlockPos p, int rgb, float a) {
        double e = 0.002;
        return new Box(p.getX() - e, p.getY() - e, p.getZ() - e, p.getX() + 1 + e, p.getY() + 1 + e, p.getZ() + 1 + e,
                ((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, a);
    }
}
