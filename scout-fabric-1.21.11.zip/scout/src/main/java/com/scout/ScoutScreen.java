package com.scout;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/**
 * Sadece vanilla Button'lar kullanir: dokunmatik ekranda (mobil) dogrudan calisir,
 * mobil modda butonlar buyur, tek sutun + sayfalama kullanilir.
 */
public class ScoutScreen extends Screen {
    private enum Tab {
        STORAGE("Storage"), SPAWNER("Spawner"), CHUNKS("Chunks"), MISC("Misc");
        final String label;
        Tab(String l) { label = l; }
    }

    private static Tab tab = Tab.STORAGE;
    private static int page = 0;

    private final Screen parent;
    private final List<IntConsumer> rows = new ArrayList<>();
    private int left, pw, bh;
    private static final int GAP = 4;

    public ScoutScreen(Screen parent) {
        super(Component.literal("Scout"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        Config c = Config.get();
        bh = c.mobileMode ? 30 : 20;
        pw = Math.min(width - 16, c.mobileMode ? 320 : 400);
        left = (width - pw) / 2;

        // Sekmeler
        int y = 20;
        Tab[] tabs = Tab.values();
        int tw = (pw - GAP * (tabs.length - 1)) / tabs.length;
        for (int i = 0; i < tabs.length; i++) {
            Tab t = tabs[i];
            Button b = Button.builder(Component.literal(t == tab ? "[" + t.label + "]" : t.label), btn -> {
                tab = t; page = 0; rebuildWidgets();
            }).bounds(left + i * (tw + GAP), y, tw, bh).build();
            addRenderableWidget(b);
        }

        // Satirlar
        rows.clear();
        switch (tab) {
            case STORAGE -> buildStorage(c);
            case SPAWNER -> buildSpawner(c);
            case CHUNKS -> buildChunks(c);
            case MISC -> buildMisc(c);
        }

        int top = y + bh + 6;
        int navY = height - bh - 6;
        int per = Math.max(1, (navY - top - 4) / (bh + GAP));
        int pages = Math.max(1, (rows.size() + per - 1) / per);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = page * per; i < Math.min(rows.size(), (page + 1) * per); i++) {
            rows.get(i).accept(top + (i - page * per) * (bh + GAP));
        }

        // Alt gezinme: < | 1/3 | > | Kapat
        int nw = (pw - GAP * 3) / 4;
        addRenderableWidget(Button.builder(Component.literal("<"), b -> { page--; rebuildWidgets(); })
                .bounds(left, navY, nw, bh).build()).active = page > 0;
        Button lbl = Button.builder(Component.literal((page + 1) + "/" + pages), b -> {})
                .bounds(left + nw + GAP, navY, nw, bh).build();
        lbl.active = false;
        addRenderableWidget(lbl);
        final int fp = pages;
        addRenderableWidget(Button.builder(Component.literal(">"), b -> { page++; rebuildWidgets(); })
                .bounds(left + 2 * (nw + GAP), navY, nw, bh).build()).active = page < fp - 1;
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(left + 3 * (nw + GAP), navY, nw, bh).build());
    }

    // ------------------------------------------------------------ sekmeler

    private void buildStorage(Config c) {
        toggle("Storage ESP", () -> c.storageEsp, v -> c.storageEsp = v);
        toggle("Chests", () -> c.chests, v -> c.chests = v);
        toggle("Trapped Chests", () -> c.trappedChests, v -> c.trappedChests = v);
        toggle("Ender Chests", () -> c.enderChests, v -> c.enderChests = v);
        toggle("Barrels", () -> c.barrels, v -> c.barrels = v);
        toggle("Shulker Boxes", () -> c.shulkers, v -> c.shulkers = v);
        toggle("Hoppers", () -> c.hoppers, v -> c.hoppers = v);
        toggle("Dispensers/Droppers", () -> c.dispensers, v -> c.dispensers = v);
        toggle("Furnaces", () -> c.furnaces, v -> c.furnaces = v);
        stepper("Range (blocks)", () -> c.espRange, 16, 256, 16, v -> c.espRange = v);
        stepper("Opacity %", () -> c.alphaPercent, 10, 90, 5, v -> c.alphaPercent = v);
    }

    private void buildSpawner(Config c) {
        toggle("Spawner Finder", () -> c.spawnerEsp, v -> c.spawnerEsp = v);
        toggle("Chat alert on find", () -> c.spawnerChat, v -> c.spawnerChat = v);
        stepper("Range (blocks)", () -> c.espRange, 16, 256, 16, v -> c.espRange = v);
    }

    private void buildChunks(Config c) {
        toggle("Chunk Finder", () -> c.chunkFinder, v -> c.chunkFinder = v);
        stepper("Radius (chunks)", () -> c.finderRadius, 2, 16, 1, v -> c.finderRadius = v);
        stepper("Min blocks / chunk", () -> c.finderThreshold, 1, 64, 1, v -> c.finderThreshold = v);
        toggle("Highlight blocks", () -> c.showFinderBlocks, v -> c.showFinderBlocks = v);
        for (Categories.Category cat : Categories.LIST) {
            toggle(cat.label, () -> c.finderBlocks.contains(cat.id), v -> {
                if (v) c.finderBlocks.add(cat.id); else c.finderBlocks.remove(cat.id);
            });
        }
    }

    private void buildMisc(Config c) {
        toggle("Mobile mode", () -> c.mobileMode, v -> c.mobileMode = v);
        info("Open: Right Shift  or  /scout");
        info("Mobile: Pause menu > Scout");
    }

    // ------------------------------------------------------------ satir yardimcilari

    private void toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
        rows.add(y -> addRenderableWidget(Button.builder(
                Component.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF")),
                b -> { set.accept(!get.getAsBoolean()); changed(); }
        ).bounds(left, y, pw, bh).build()));
    }

    private void stepper(String label, IntSupplier get, int min, int max, int step, IntConsumer set) {
        rows.add(y -> {
            int bw = bh + 14;
            Button l = Button.builder(Component.literal(label + ": " + get.getAsInt()), b -> {})
                    .bounds(left, y, pw - 2 * bw - 2 * GAP, bh).build();
            l.active = false;
            addRenderableWidget(l);
            addRenderableWidget(Button.builder(Component.literal("-"), b -> {
                set.accept(Math.max(min, get.getAsInt() - step)); changed();
            }).bounds(left + pw - 2 * bw - GAP, y, bw, bh).build());
            addRenderableWidget(Button.builder(Component.literal("+"), b -> {
                set.accept(Math.min(max, get.getAsInt() + step)); changed();
            }).bounds(left + pw - bw, y, bw, bh).build());
        });
    }

    private void info(String text) {
        rows.add(y -> {
            Button b = Button.builder(Component.literal(text), x -> {}).bounds(left, y, pw, bh).build();
            b.active = false;
            addRenderableWidget(b);
        });
    }

    private void changed() {
        Config.save();
        Tracker.invalidate();
        rebuildWidgets();
    }

    // ------------------------------------------------------------ cizim / kapama

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(left - 6, 14, left + pw + 6, height - 2, 0xD0101018);
        g.drawCenteredString(font, "Scout", width / 2, 4, 0xFFFFFFFF);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
