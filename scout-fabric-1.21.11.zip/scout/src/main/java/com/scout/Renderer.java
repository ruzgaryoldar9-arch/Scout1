package com.scout;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * Duvarlarin arkasindan gorunen dolu kutular cizer.
 * Yapi, Fabric Docs "Rendering in the World" (1.21.11) ornegine dayanir.
 */
public final class Renderer {
    private static final RenderPipeline PIPELINE = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
                    .withLocation(Identifier.fromNamespaceAndPath("scout", "pipeline/esp_filled_through_walls"))
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .build());

    private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
    private static MappableRingBuffer vertexBuffer;

    private Renderer() {}

    public static void init() {
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(Renderer::render);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> close());
    }

    private static void render(WorldRenderContext context) {
        List<Tracker.Box> boxes = Tracker.all();
        if (boxes.isEmpty()) return;

        Vec3 cam = context.worldState().cameraRenderState.pos;
        Matrix4fc pose = context.matrices().last().pose();

        BufferBuilder buffer = new BufferBuilder(ALLOCATOR, PIPELINE.getVertexFormatMode(), PIPELINE.getVertexFormat());
        for (Tracker.Box b : boxes) {
            filledBox(pose, buffer,
                    (float) (b.x1() - cam.x), (float) (b.y1() - cam.y), (float) (b.z1() - cam.z),
                    (float) (b.x2() - cam.x), (float) (b.y2() - cam.y), (float) (b.z2() - cam.z),
                    b.r(), b.g(), b.b(), b.a());
        }

        MeshData mesh = buffer.buildOrThrow();
        MeshData.DrawState ds = mesh.drawState();
        VertexFormat format = ds.format();
        GpuBuffer vertices = upload(ds, format, mesh);
        draw(Minecraft.getInstance(), mesh, ds, vertices, format);
        vertexBuffer.rotate();
    }

    private static void filledBox(Matrix4fc m, BufferBuilder buf, float x1, float y1, float z1, float x2, float y2, float z2,
                                  float r, float g, float b, float a) {
        // Front
        buf.addVertex(m, x1, y1, z2).setColor(r, g, b, a); buf.addVertex(m, x2, y1, z2).setColor(r, g, b, a);
        buf.addVertex(m, x2, y2, z2).setColor(r, g, b, a); buf.addVertex(m, x1, y2, z2).setColor(r, g, b, a);
        // Back
        buf.addVertex(m, x2, y1, z1).setColor(r, g, b, a); buf.addVertex(m, x1, y1, z1).setColor(r, g, b, a);
        buf.addVertex(m, x1, y2, z1).setColor(r, g, b, a); buf.addVertex(m, x2, y2, z1).setColor(r, g, b, a);
        // Left
        buf.addVertex(m, x1, y1, z1).setColor(r, g, b, a); buf.addVertex(m, x1, y1, z2).setColor(r, g, b, a);
        buf.addVertex(m, x1, y2, z2).setColor(r, g, b, a); buf.addVertex(m, x1, y2, z1).setColor(r, g, b, a);
        // Right
        buf.addVertex(m, x2, y1, z2).setColor(r, g, b, a); buf.addVertex(m, x2, y1, z1).setColor(r, g, b, a);
        buf.addVertex(m, x2, y2, z1).setColor(r, g, b, a); buf.addVertex(m, x2, y2, z2).setColor(r, g, b, a);
        // Top
        buf.addVertex(m, x1, y2, z2).setColor(r, g, b, a); buf.addVertex(m, x2, y2, z2).setColor(r, g, b, a);
        buf.addVertex(m, x2, y2, z1).setColor(r, g, b, a); buf.addVertex(m, x1, y2, z1).setColor(r, g, b, a);
        // Bottom
        buf.addVertex(m, x1, y1, z1).setColor(r, g, b, a); buf.addVertex(m, x2, y1, z1).setColor(r, g, b, a);
        buf.addVertex(m, x2, y1, z2).setColor(r, g, b, a); buf.addVertex(m, x1, y1, z2).setColor(r, g, b, a);
    }

    private static GpuBuffer upload(MeshData.DrawState ds, VertexFormat format, MeshData mesh) {
        int size = ds.vertexCount() * format.getVertexSize();
        if (vertexBuffer == null || vertexBuffer.size() < size) {
            if (vertexBuffer != null) vertexBuffer.close();
            vertexBuffer = new MappableRingBuffer(() -> "scout esp vertices",
                    GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, size);
        }
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        try (GpuBuffer.MappedView view = encoder.mapBuffer(
                vertexBuffer.currentBuffer().slice(0, mesh.vertexBuffer().remaining()), false, true)) {
            MemoryUtil.memCopy(mesh.vertexBuffer(), view.data());
        }
        return vertexBuffer.currentBuffer();
    }

    private static void draw(Minecraft mc, MeshData mesh, MeshData.DrawState ds, GpuBuffer vertices, VertexFormat format) {
        mesh.sortQuads(ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
        GpuBuffer indices = PIPELINE.getVertexFormat().uploadImmediateIndexBuffer(mesh.indexBuffer());
        VertexFormat.IndexType indexType = mesh.drawState().indexType();

        GpuBufferSlice transforms = RenderSystem.getDynamicUniforms()
                .writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);
        try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
                () -> "scout esp", mc.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(),
                mc.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty())) {
            pass.setPipeline(PIPELINE);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", transforms);
            pass.setVertexBuffer(0, vertices);
            pass.setIndexBuffer(indices, indexType);
            pass.drawIndexed(0, 0, ds.indexCount(), 1);
        }
        mesh.close();
    }

    public static void close() {
        ALLOCATOR.close();
        if (vertexBuffer != null) { vertexBuffer.close(); vertexBuffer = null; }
    }
}
