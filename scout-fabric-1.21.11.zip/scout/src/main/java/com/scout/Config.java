package com.scout;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Config {
    // Ana moduller
    public boolean storageEsp = true;
    public boolean spawnerEsp = true;
    public boolean chunkFinder = false;
    public boolean mobileMode = detectMobile();

    // Storage tipleri
    public boolean chests = true, trappedChests = true, enderChests = true, barrels = true,
            shulkers = true, hoppers = false, dispensers = false, furnaces = false;

    // Spawner
    public boolean spawnerChat = true;

    // Ortak
    public int espRange = 96;       // blok
    public int alphaPercent = 35;   // kutu opakligi

    // Chunk finder
    public int finderRadius = 8;    // chunk
    public int finderThreshold = 3; // chunk basina min. blok
    public boolean showFinderBlocks = false;
    public Set<String> finderBlocks = new HashSet<>(List.of("budding_amethyst", "amethyst"));

    // ---- kalicilik ----
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config instance;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("scout.json");
    }

    public static Config get() {
        if (instance == null) {
            try {
                Path f = file();
                if (Files.exists(f)) instance = GSON.fromJson(Files.readString(f), Config.class);
            } catch (Exception ignored) {}
            if (instance == null) instance = new Config();
            if (instance.finderBlocks == null) instance.finderBlocks = new HashSet<>();
        }
        return instance;
    }

    public static void save() {
        try {
            Files.writeString(file(), GSON.toJson(get()));
        } catch (Exception ignored) {}
    }

    /** PojavLauncher / Zalith gibi mobil launcher'lari tahmin eder; GUI'den elle de degistirilebilir. */
    private static boolean detectMobile() {
        return System.getenv("POJAV_RENDERER") != null
                || System.getenv("POJAV_NATIVEDIR") != null
                || System.getProperty("os.name", "").toLowerCase().contains("android");
    }
}
