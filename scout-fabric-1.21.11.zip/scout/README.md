# Scout (Fabric, Minecraft 1.21.11)

Ozellikler: Storage ESP, Spawner Finder, Chunk Finder (amethyst, kelp, sugar cane... secilebilir), GUI (Sag Shift).
Mojang mappings kullanir (1.21.11'de Yarn yok).

## Derleme
1. https://fabricmc.net/develop/template/ adresinden 1.21.11 icin bos template olustur (gradle wrapper icin)
   VEYA bu klasorde `gradle wrapper` calistir.
2. gradle.properties icindeki loader / fabric_api / loom surumlerini fabricmc.net/develop'tan guncelle.
3. `./gradlew build`  ->  build/libs/scout-1.0.0.jar  -> mods klasorune at (Fabric API ile birlikte).

## Acma
- PC: Sag Shift (Options > Controls > Key Binds > Scout'tan degistirilir)
- Mobil: Pause menusu sol ustte "Scout" butonu, ya da sohbete /scout yaz.
  Launcher'in kontrol duzenine "Right Shift" tusu atayabilirsin.
- Ayarlar .minecraft/config/scout.json icinde saklanir.
